"""
Core functionality for the data collection modules of the Cloud Forensics AI Agent.
"""
