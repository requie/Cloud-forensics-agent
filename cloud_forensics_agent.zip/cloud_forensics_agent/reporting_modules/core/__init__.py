"""
Core functionality for the reporting modules of the Cloud Forensics AI Agent.
"""
