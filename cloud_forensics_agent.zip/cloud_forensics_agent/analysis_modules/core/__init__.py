"""
Core functionality for the analysis modules of the Cloud Forensics AI Agent.
"""
